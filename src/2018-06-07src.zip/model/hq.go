package model

type Hq struct {
	Code string
}
