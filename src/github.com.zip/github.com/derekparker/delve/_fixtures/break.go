package main

func main() {
	i := 0
	for {
		i++
		if i > 10 {
			break
		}
	}
}
